1. Create virtual environment 
2. Install libraries 
	'pip install numpy'
	'pip install mtplotlib'
3. Launch programm